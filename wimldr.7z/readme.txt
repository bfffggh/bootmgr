Please copy your boot.wim to EFI\Microsoft\Boot\boot.wim

This bootloader won't work on BIOS! It'll only work on UEFI.
If the filesystem of the target drive isn't FAT32, please format the target drive with the FAT32 filesystem.

The bootscreen should look like the Windows Vista bootscreen.

Remember! This bootloader is x64, not x86 or ARM64!